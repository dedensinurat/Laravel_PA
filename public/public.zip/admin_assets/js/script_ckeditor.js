ClassicEditor
.create(document.querySelector('#visi_sekolah'))
.catch(error => {
    console.error(error);
});
ClassicEditor
.create(document.querySelector('#misi_sekolah'))
.catch(error => {
    console.error(error);
});
ClassicEditor
.create(document.querySelector('#sambutan_kepsek'))
.catch(error => {
    console.error(error);
});
ClassicEditor
.create(document.querySelector('#deskripsi_sejarah'))
.catch(error => {
    console.error(error);
});
ClassicEditor
.create(document.querySelector('#isi_pengumuman'))
.catch(error => {
    console.error(error);
});
ClassicEditor
.create(document.querySelector('#deskripsi_prestasi'))
.catch(error => {
    console.error(error);
});
ClassicEditor
.create(document.querySelector('#isi_kegiatan'))
.catch(error => {
    console.error(error);
});
